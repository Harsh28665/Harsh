//Write a program to print the sum of the first n odd numbers.
#include <stdio.h>
int main()
{
    int n;
    printf("enter n\n");
    scanf("%d",&n);
    int i = 0;
    while (i<n)
    {
        int sum = sum+i+;
        i++;
        printf("the sum is %d",sum);
        
    }
    return 0 ;
    
}