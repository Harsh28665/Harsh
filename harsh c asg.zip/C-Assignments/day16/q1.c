"// C code here" 
