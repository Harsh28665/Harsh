//Write a program to print all the prime numbers from 1 to n.
#include <stdio.h>
int main()
{
    int n;
    printf("enter the number n");
    scanf("%d",&n);
    for (int i = 1; i < n; i++)
    {
        if (n%i==0&&n)
        {
            /* code */
        }
        
    }
    
}