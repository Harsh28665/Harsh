//Write a program to find the LCM of two numbers.
#include <stdio.h>
int main()
{
    int n1 ,n2,min ;
    printf("enter numbers\n");
    scanf("%d %d",&n1 &n2);
    min = (n1 < n2) ? n1 : n2;
    int i=0;
    int num=0;
    while (i<min)
    {
        if ()
        {
            /* code */
        }
        
    }
}
