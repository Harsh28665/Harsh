//Write a program to input two numbers and display their sum.
#include <stdio.h>
int main()
{
    int num1;
    printf("enter first number :\n");
    scanf("%d",&num1);
    int num2;
    printf("enter second number :\n");
    scanf("%d",&num2);
    printf("the sum is %d",num1+num2);
    return 0;

}
