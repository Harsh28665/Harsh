//Write a program to input a character and check whether it is an uppercase alphabet, lowercase alphabet, digit, or special character.
